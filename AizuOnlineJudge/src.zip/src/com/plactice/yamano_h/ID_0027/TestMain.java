package com.plactice.yamano_h.ID_0027;

import org.junit.Test;

public class TestMain {
	@Test
	public void testMain() throws Exception {
		Main.main(null);
	}
}
