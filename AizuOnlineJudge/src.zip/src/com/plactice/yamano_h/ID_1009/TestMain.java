package com.plactice.yamano_h.ID_1009;

import org.junit.Test;

public class TestMain {
	@Test
	public void testMain() throws Exception {
		System.out.println("AA");
		Main.main(null);
	}
}
