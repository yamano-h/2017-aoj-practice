package com.plactice.yamano_h.ID_0025;

import org.junit.Test;

public class TestMain {
	@Test
	public void testMain() throws Exception {
//		Main.main(null);
		String[] a = new String[3];
		String[] b = new String[3];
		a[0] = "1";
		b[0] = "1";
		System.out.println(a[0] == b[0]);
			
	}
}
