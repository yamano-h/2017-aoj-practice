package com.plactice.shirakawa_d.q0002;

import org.junit.Test;

public class TestMain {
	@Test
	public void testMain() throws Exception {
		Main.main(null);
	}
}
