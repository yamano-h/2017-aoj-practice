package com.plactice.shirakawa_d.ITP1_1_B;

import org.junit.Test;

public class TestMain {
	@Test
	public void testMain() throws Exception {
		Main.main(null);
	}
}
